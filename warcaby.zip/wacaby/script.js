function aha() {
    for (let k = 1; k <= 5; k++) {
        for (let i = 1; i <= 6; i++) {
            for (let j = 1; j <= 6; j++) {
        document.getElementById = `pl${k}_tr${i}_td${j}`;
        if (pl == 1 || pl == 5) {
            console.log("aha");
        }
            }
        }
         
        }
    }
