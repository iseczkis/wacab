<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <!-- <script src="script.js"></script>  -->
    <title>Document</title>
</head>


<body>
    <h1>Warcaby 2</h1>
    <div class="kontener">
        <?php
        for ($k = 1; $k <= 5; $k++) {
            if ($k == 2) {
                echo "<div class='srodek'>";
            }
            echo "<table id='tabela{$k}'>";
            // nr tr
            for ($i = 1; $i <= 6; $i++) {
                echo "<tr>";
                // nr td
                for ($j = 1; $j <= 6; $j++) {
                    if (($i % 2 == 0 && $j % 2 == 1)  || ($i % 2 == 1 && $j % 2 == 0)) {
                        if($k==1 && $i<=2){
                            echo "<td class='czarny' id='pl{$k}_tr{$i}_td{$j}'>";
                            echo "<img src='img/kaczka2.png'>";
                            echo "</td>";
                        }elseif($k==5 && $i>=5){
                            echo "<td class='czarny' id='pl{$k}_tr{$i}_td{$j}'>";
                            echo "<img src='img/zaba2.png'>";
                            echo "</td>";
                        }else{
                            echo "<td class='czarny' id='pl{$k}_tr{$i}_td{$j}'></td>";
                        }
                    } else {
                        echo "<td id='pl{$k}_tr{$i}_td{$j}'></td>";
                    }
                }
                echo "</tr>";
            }
            echo "</table>";
            if ($k == 4) {
                echo "</div>";
            }
        }
        ?>
    </div><br>
    <div class="kostki">
        <span class="info">Teraz rzuca: gracz 1</span><br>
        <span class="k1">1</span>
        <span class="k2">2</span><br>
        <input type="button" value="Rzuć kośćmi" onclick="">
    </div>
</body>

</html>